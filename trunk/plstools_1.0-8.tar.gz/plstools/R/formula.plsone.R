`formula.plsone` <-
function (x, ...)
{
    x$formula
}

