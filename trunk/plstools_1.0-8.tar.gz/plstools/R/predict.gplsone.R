`predict.gplsone` <-
function(object,newdata=NULL,type="link",se.fit=FALSE,interval="none",level=0.95,...)
{
  if (!inherits(object,"gplsone"))
    stop("object 'gplsone' expected")
  .NotYetImplemented()
}
