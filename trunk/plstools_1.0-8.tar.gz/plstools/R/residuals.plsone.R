`residuals.plsone` <-
function(object,...){
  residuals(object$lm,...)
}
