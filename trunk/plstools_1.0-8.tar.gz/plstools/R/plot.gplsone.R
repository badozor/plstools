`plot.gplsone` <-
function(x,xax=1,yax=2,...)
{
  if (!inherits(x,"gplsone"))
    stop("object 'gplsone' expected")
  .NotYetImplemented()
}
