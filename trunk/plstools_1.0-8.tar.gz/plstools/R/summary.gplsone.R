`summary.gplsone` <-
function(object,...){
  if (!inherits(object,"gplsone"))
    stop("object 'gplsone' expected")
  .NotYetImplemented()
  class(res) <- "summary.gplsone"
  return(res)
}
