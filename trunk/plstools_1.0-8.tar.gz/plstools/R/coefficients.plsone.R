`coefficients.plsone` <-
function(object,...){
  coef(object,...)
}
