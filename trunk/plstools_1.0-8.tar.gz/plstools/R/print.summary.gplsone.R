`print.summary.gplsone` <-
function(x,...){
  if (!inherits(x,"summary.gplsone"))
    stop("object 'gplsone' expected")
  .NotYetImplemented()
}
