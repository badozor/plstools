`residuals.gplsone` <-
function(object,...){
  residuals(object$glm,...)
}
